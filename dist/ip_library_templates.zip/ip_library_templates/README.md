# Документация IP - редакция 2.0

Обновлено 2026-10-26 по прикреплённым SGC77 LDO rev. 0.7 и SGC67 DC/DC rev. 1.9 с учётом Virtuoso, ADE L/XL, Liberate и Calibre PEX/DRC/LVS. Исходные PDF и их фирменная графика в архив не включены.

## С чего начать

1. `datasheet_template.md` - универсальная структура с пояснениями к каждому разделу.
2. `datasheet_LDO_template.md` - заполняемый LDO-шаблон, 24 группы параметров с пояснениями и методом.
3. `LDO_measurement_guide.md` / `.pdf` - подробные рецепты, setup в ADE, формулы, ошибки и post-layout flow.
4. `datasheet_LDO_example.md` - переработанный пример 1.2 V / 5 mA с условными числами, не копия SGC77.
5. `images_in_yaml.md`, `datasheet_media.yaml`, `figures/` - реальная связка изображения и metadata.
6. `DC_DC_extension.md` - switching-specific дополнение по SGC67; не переносить его методы в LDO без проверки.

`datasheet_template_v2.pdf` - читаемая PDF-версия универсального шаблона. Markdown остаётся редактируемым исходником.

## Что изменилось

Добавлены configuration, domains, bias compliance, sense/ground, test modes, подробные measurement cards, routing budgets и понятное разделение observed/target/guaranteed. Разведены absolute/normalized line-load regulation, ASD/PSD/integrated noise, rise/settling time, nominal output current и protection current.

PERC deck для процесса отсутствует: PERC=not_run, reason=deck_not_available. Электрические проверки ограничены реально доступным deck coverage и документированным review. Это не PERC PASS и не автоматическая ESD/reliability квалификация.

В рецептах принят Spectre как simulator под ADE; его выбор/version необходимо проверить в установленном flow. Дополнительные RF/AMS возможности не предполагаются доступными по умолчанию.

## Рисунки и измеренные результаты

В figures находятся собственные функциональные диаграммы (PNG + SVG), не результаты моделирования. Реальные waveform/CSV/plots нужно добавить после запусков. YAML хранит пути, подписи и связи; Markdown/PDF показывает графику. Ни одна демонстрационная цифра не является silicon или signoff result.

## Шаблоны waiver из предыдущей редакции

Сохранены generic/DRC/ERC/ESD/antenna YAML и два примера с synthetic summary. Пример ESD/PERC формы не означает наличие PERC deck или выполненной проверки в вашем процессе. Внутренние и foundry approvals в примерах отсутствуют.

## Как использовать summary как основу waiver

Да, для внутреннего формата можно сохранить сам summary и добавить описание решений. Применимость такого документа для конкретной фабрики определяется её процедурой. Исходный отчёт не редактируется и не помечается PASS из-за наличия YAML.

Структура YAML:

1. `heading`, `description` — заголовок и общее пояснение до списка ошибок.
2. `scope` — IP/release, контекст, входные файлы, Run ID, инструмент, rule deck, настройки.
3. `summary_source` — путь и SHA-256 исходного summary, ссылка на полный отчёт / results database.
4. `source_summary` — исходный текст summary как многострочное значение `|`. Если отчёт большой или не является текстом, достаточно ссылки и SHA-256; `source_summary` можно заменить на `null`.
5. `violations` — список правил с количеством, причиной, влиянием, ограничением и статусом решения.
6. `approval` — отдельные поля внутреннего согласования и решения фабрики.

Пути в реальных файлах считаются **от корня релиза IP**, не от каталога YAML. В примерах корень — каталог этого комплекта. Хэш вычисляется по точным байтам указанного файла, включая сжатие, если путь оканчивается на `.gz`. Хэш summary — по исходному файлу, не по повторно сериализованному YAML-блоку.

### Одна строка на правило, а не на каждую геометрию

Удобно переносить из summary все правила с ненулевым количеством. Если причина и решение одинаковые для всех markers, достаточно одной записи с `count: N` и ссылкой на results database. Если причина, область или решение различаются, разбить правило на несколько записей с непересекающимися marker_refs. Не выдавать согласование одного marker за согласование всех нарушений правила.

Для каждой записи обязательны `rule_id`, точный `message`, `count`, `reason`, `impact`, `required_action`, `disposition`, `owner`. Список evidence заполняется ссылками на доказательства; скриншот нужен там, где он помогает проверить обоснование. `details` расширяет сведения для конкретного типа проверки.

**Идентификатор правила нельзя интерпретировать по памяти:** например, содержание `po.dn.3` определяется только фактическим deck/отчётом вашего процесса. В примерах используются вымышленные `EXAMPLE.*`.

### Статусы и счётчики

| Поле | Допустимые значения / смысл |
|---|---|
| `document_status` | `draft`, `in_review`, `approved`, `obsolete`; `example_only` только для демонстраций |
| `results.tool_status` | `not_evaluated`, `clean`, `violations`, `run_failed` — нормализованное представление исходного результата |
| `results.review_status` | `pending`, `accepted`, `requires_integration`, `rejected` — результат инженерного рассмотрения |
| `violations[].disposition` | `pending`, `accepted`, `rejected`, `requires_integration` |
| `approval.internal.status` | `pending`, `approved`, `rejected` |
| `approval.foundry.status` | `not_requested`, `pending`, `approved`, `rejected`, `not_required`; для `not_required` записать основание в note |

`requires_integration` — незакрытое требование к верхнему уровню, не окончательное исключение. `accepted` используется только после соответствующего решения. Кандидаты и черновики по умолчанию остаются pending.

`listed_markers` = сумма `count` в violations; сумма accepted/requires_integration/pending/rejected должна равняться listed_markers. Для полного списка `listed_markers` = `total_markers`. Счётчик учитывает findings/markers в единицах исходного отчёта, не число правил и не число полигонов внутри marker. Если данных нет, использовать YAML `null`, а не ложный ноль.

Чтобы согласовать весь список одним решением, внутреннее approval ссылается на точный summary и scope. Внутреннее согласование не означает согласование фабрики. Изменение layout/netlist, PDK/deck, параметров запуска или контекста требует пересмотра применимости документа.

### Особенность ERC/ESD

Фраза вроде «nwell connected to ground» сама по себе не доказывает допустимость соединения. Нужны фактический тип well/device, допустимые потенциалы и состояния питания. Если обоснования нет, замечание остаётся pending; так оформлена отдельная запись примера ERC.

ESD/PERC и antenna шаблоны используют ту же структуру, но требуют данных своего метода. Наличие block-level waiver не заменяет применимые проверки конечного кристалла и его защиты.


## Проверки документации

YAML должен проходить safe parse и проверку duplicate keys. Все figure paths должны существовать, а synthetic summary hashes/counts совпадать. PDF проверяется после рендера. Эти проверки относятся к формату; они не подтверждают работу IP.
